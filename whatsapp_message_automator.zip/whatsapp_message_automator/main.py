import pywhatkit as pyw
pyw.sendwhatmsg('+923093000758','My automated msg',9,56)