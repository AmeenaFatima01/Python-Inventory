from pdf2docx import Converter

old_pdf= "mypdf.pdf"
new_doc="converted.docx"
obj=Converter(old_pdf)
obj.convert(new_doc)
obj.close()
