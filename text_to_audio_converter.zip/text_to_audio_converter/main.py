from gtts import gTTS
import os

f=open('Intro.txt')
x=f.read()

language='en'

audio=gTTS(text=x,lang=language,slow=False)

audio.save("Intro.wav")
os.system("Intro.wav")
