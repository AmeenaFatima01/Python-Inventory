class Student:
    def __init__(self, name, age, grade):
        self.name = name
        self.age = age
        self.grade = grade

    def __str__(self):
        return f"Name: {self.name}, Age: {self.age}, Grade: {self.grade}"


class StudentManagementSystem:
    def __init__(self):
        self.students = []

    def add_student(self, name, age, grade):
        student = Student(name, age, grade)
        self.students.append(student)
        print(f"{name} has been added to the student list.")

    def remove_student(self, name):
        for student in self.students:
            if student.name == name:
                self.students.remove(student)
                print(f"{name} has been removed from the student list.")
                return
        print(f"{name} was not found in the student list.")

    def display_students(self):
        if len(self.students) == 0:
            print("No students found in the list.")
            return
        for student in self.students:
            print(student)


def main():
    sms = StudentManagementSystem()

    while True:
        print("Student Management System")
        print("1. Add Student")
        print("2. Remove Student")
        print("3. Display Students")
        print("4. Exit")
        choice = int(input("Enter your choice: "))
        print()

        if choice == 1:
            name = input("Enter student name: ")
            age = int(input("Enter student age: "))
            grade = int(input("Enter student grade: "))
            sms.add_student(name, age, grade)
        elif choice == 2:
            name = input("Enter student name to remove: ")
            sms.remove_student(name)
        elif choice == 3:
            sms.display_students()
        elif choice == 4:
            break
        else:
            print("Error: Invalid choice")
        print()


if __name__ == '__main__':
    main()
