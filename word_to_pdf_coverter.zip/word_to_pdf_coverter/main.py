from docx2pdf import convert

convert("converted.docx","pdf_again.pdf")
