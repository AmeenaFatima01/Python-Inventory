class Patient:
    def __init__(self, name, age, address, medical_history):
        self.name = name
        self.age = age
        self.address = address
        self.medical_history = medical_history

class Doctor:
    def __init__(self, name, specialization):
        self.name = name
        self.specialization = specialization

class Inventory:
    def __init__(self, medicine, equipment, supplies):
        self.medicine = medicine
        self.equipment = equipment
        self.supplies = supplies

class Appointment:
    def __init__(self, patient, doctor, date, time):
        self.patient = patient
        self.doctor = doctor
        self.date = date
        self.time = time

patients = []
doctors = []
inventory = []
appointments = []

def add_patient(name, age, address, medical_history):
    p = Patient(name, age, address, medical_history)
    patients.append(p)

def add_doctor(name, specialization):
    d = Doctor(name, specialization)
    doctors.append(d)

def add_item(medicine, equipment, supplies):
    i = Inventory(medicine, equipment, supplies)
    inventory.append(i)

def add_appointment(patient, doctor, date, time):
    a = Appointment(patient, doctor, date, time)
    appointments.append(a)

def display_patients():
    for p in patients:
        print("Name:", p.name)
        print("Age:", p.age)
        print("Address:", p.address)
        print("Medical History:", p.medical_history)
        print()

def display_doctors():
    for d in doctors:
        print("Name:", d.name)
        print("Specialization:", d.specialization)
        print()

def display_inventory():
    for i in inventory:
        print("Medicine:", i.medicine)
        print("Equipment:", i.equipment)
        print("Supplies:", i.supplies)
        print()

def display_appointments():
    for a in appointments:
        print("Patient:", a.patient.name)
        print("Doctor:", a.doctor.name)
        print("Date:", a.date)
        print("Time:", a.time)
        print()


def main():
    while True:
        print("Hospital Management System")
        print("1. Add Patient")
        print("2. Add Doctor")
        print("3. Add Inventory Item")
        print("4. Add Appointment")
        print("5. Display Patients")
        print("6. Display Doctors")
        print("7. Display Inventory")
        print("8. Display Appointments")
        print("9. Exit")
        choice = int(input("Enter your choice: "))
        print()

        if choice == 1:
            name = input("Enter patient name: ")
            age = int(input("Enter patient age: "))
            address = input("Enter patient address: ")
            medical_history = input("Enter patient medical history: ")
            add_patient(name, age, address, medical_history)
        elif choice == 2:
            name = input("Enter doctor name: ")
            specialization = input("Enter doctor specialization: ")
            add_doctor(name, specialization)
        elif choice == 3:
            medicine = input("Enter medicine name: ")
            equipment = input("Enter equipment name: ")
            supplies = input("Enter supplies name: ")
            add_item(medicine, equipment, supplies)
        elif choice == 4:
            patient_name = input("Enter patient name: ")
            doctor_name = input("Enter doctor name: ")
            date = input("Enter appointment date: ")
            time = input("Enter appointment time: ")
            patient = None
            for p in patients:
                if p.name == patient_name:
                    patient = p
                    break
            doctor = None
            for d in doctors:
                if d.name == doctor_name:
                    doctor = d
                    break
            if patient is not None and doctor is not None:
                add_appointment(patient, doctor, date, time)
            else:
                print("Error: Invalid patient or doctor name")
        elif choice == 5:
            display_patients()
        elif choice == 6:
            display_doctors()
        elif choice == 7:
            display_inventory()
        elif choice == 8:
            display_appointments()
        elif choice == 9:
            break
        else:
            print("Error: Invalid choice")
        print()

if __name__ == '__main__':
    main()
